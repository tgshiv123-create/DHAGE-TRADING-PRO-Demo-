DHAGE TRADING PRO PWA STARTER

Files:
- index.html: put your existing demo HTML here
- manifest.json: PWA name, display mode, colors and icon references
- service-worker.js: basic offline app-shell caching
- icons/: app icons

IMPORTANT:
1. This folder needs to be served from an HTTPS website for normal PWA installation on Android.
2. Acode's local preview/file URL usually is not enough to install a PWA.
3. Upload all files/folders to the same website directory, keeping the paths unchanged.
4. Open the HTTPS website in Chrome on Android, then Chrome menu > Add to Home screen / Install app.
5. Demo only: no live market feed or real order execution.
